// App shell: hash router, navigation bar, login/register dialog and the live-availability stream.
import { $, $$, esc, toast, closeModal, errorState } from './ui.js';
import { showAuth } from './auth.js';
import { session, loadUser, logout, onSession, isAdmin } from './session.js';
import { bus } from './bus.js';
import * as home from './pages/home.js';
import * as listing from './pages/listing.js';
import * as hotel from './pages/hotel.js';
import * as booking from './pages/booking.js';
import * as confirmation from './pages/confirmation.js';
import * as myBookings from './pages/myBookings.js';
import * as admin from './pages/admin.js';

const routes = [
  [/^#?\/?$/, home], [/^#\/hotels$/, listing], [/^#\/hotel\/(\d+)$/, hotel], [/^#\/book$/, booking],
  [/^#\/booking\/([A-Za-z0-9-]+)$/, confirmation], [/^#\/my-bookings$/, myBookings], [/^#\/admin(?:\/(\w+))?$/, admin],
];
let cleanup = null;

async function route() {
  const hash = location.hash || '#/';
  const [path, query = ''] = hash.split('?');
  const root = $('#app');
  if (cleanup) { try { cleanup(); } catch { /* ignore */ } cleanup = null; }
  $('#nav-links').classList.remove('open');
  window.scrollTo(0, 0);
  const found = routes.find(([re]) => re.test(path));
  if (!found) {
    root.innerHTML = `<div class="container page-pad"><div class="empty"><div class="big">🧭</div><h2>Page not found</h2><p class="muted">That page doesn't exist.</p><a class="btn btn-primary" href="#/">Back to home</a></div></div>`;
    return;
  }
  const [re, page] = found;
  const args = path.match(re).slice(1);
  renderNav();
  try {
    cleanup = (await page.render(root, { params: new URLSearchParams(query), args, reload: route })) || null;
  } catch (err) {
    root.innerHTML = `<div class="container page-pad">${errorState(err.message)}</div>`;
    $('[data-retry]', root).onclick = route;
  }
  root.focus({ preventScroll: true });
}

function renderNav() {
  const u = session.user, h = location.hash || '#/';
  const on = (p) => (h.startsWith(p) ? 'active' : '');
  $('#nav-links').innerHTML = `
    <a class="link ${h === '#/' || h === '' ? 'active' : ''}" href="#/">Home</a>
    <a class="link ${on('#/hotels')}" href="#/hotels">Hotels</a>
    ${u ? `<a class="link ${on('#/my-bookings')}" href="#/my-bookings">My bookings</a>` : ''}
    ${isAdmin() ? `<a class="link ${on('#/admin')}" href="#/admin">Admin</a>` : ''}
    ${u ? `<span class="link" style="display:flex;align-items:center"><span class="avatar">${esc(u.name[0].toUpperCase())}</span>${esc(u.name.split(' ')[0])}</span>
           <button class="link" id="logout">Log out</button>`
        : `<button class="link" id="login">Log in</button><button class="btn btn-primary btn-sm" id="signup">Sign up</button>`}`;
  $('#login')?.addEventListener('click', () => showAuth('login'));
  $('#signup')?.addEventListener('click', () => showAuth('register'));
  $('#logout')?.addEventListener('click', () => { logout(); toast('You have been logged out', 'info'); if (/my-bookings|admin|book/.test(location.hash)) location.hash = '#/'; else route(); });
}

// Live availability: the server pushes an event whenever a room is booked or cancelled anywhere.
function connectEvents() {
  if (!window.EventSource) return;
  const es = new EventSource('/api/events');
  es.addEventListener('availability', (e) => { try { bus.emit('availability', JSON.parse(e.data)); } catch { /* ignore */ } });
}

window.addEventListener('hashchange', route);
window.addEventListener('session-expired', () => { onSessionChange(); toast('Your session expired. Please log in again.', 'info'); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });
$('#burger').addEventListener('click', () => {
  const open = $('#nav-links').classList.toggle('open');
  $('#burger').setAttribute('aria-expanded', String(open));
});
const onSessionChange = () => renderNav();
onSession(onSessionChange);
bus.on('login', route); // after a successful login, redraw the current page

(async () => {
  await loadUser();
  connectEvents();
  route();
})();
