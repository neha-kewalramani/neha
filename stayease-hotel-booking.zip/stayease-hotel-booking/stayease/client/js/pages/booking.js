// Booking flow: 1) guest details → 2) review → (confirm) → confirmation page with the Booking ID
import { api, qs } from '../api.js';
import { $, $$, esc, money, img, plural, stars, fmtDate, toast, busy, priceRows, addDays, diffDays, todayISO } from '../ui.js';
import { session } from '../session.js';
import { showAuth } from '../auth.js';
import { bus } from '../bus.js';

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const PHONE = /^(\+91)?[6-9]\d{9}$/;

export async function render(root, { params }) {
  const g = (k, d) => params.get(k) ?? d;
  const input = { roomId: Number(g('roomId')), checkIn: g('checkIn', ''), checkOut: g('checkOut', ''), rooms: Number(g('rooms', 1)), adults: Number(g('adults', 2)), children: Number(g('children', 0)) };
  if (!input.roomId || !input.checkIn || !input.checkOut) {
    root.innerHTML = `<div class="container page-pad"><div class="empty"><div class="big">🧳</div><h2>Choose a room first</h2><p class="muted">Pick a hotel and room to start your booking.</p><a class="btn btn-primary" href="#/hotels">Browse hotels</a></div></div>`;
    return;
  }
  if (!session.user) {
    root.innerHTML = `<div class="container page-pad"><div class="empty"><div class="big">🔐</div><h2>Log in to book</h2><p class="muted">We need an account to keep your booking safe and show it in My bookings.</p><button class="btn btn-primary" id="go-login">Log in or sign up</button></div></div>`;
    $('#go-login', root).onclick = () => showAuth('login');
    showAuth('login', 'Log in or create an account to continue with your booking.');
    return;
  }

  const { room, hotel } = await api('/rooms/' + input.roomId);
  const nights = diffDays(input.checkIn, input.checkOut);
  let quote = null, coupon = '', step = 1, soldOut = false;
  const form = { name: session.user.name, email: session.user.email, phone: '', others: [], requests: '' };
  const extraCount = Math.min(input.adults + input.children - 1, 9);
  form.others = Array(extraCount).fill('');

  root.innerHTML = `<div class="container page-pad fade-in">
    <p class="crumbs"><a href="#/hotel/${hotel.id}?${qs({ checkIn: input.checkIn, checkOut: input.checkOut, adults: input.adults, children: input.children, rooms: input.rooms })}">← Back to ${esc(hotel.name)}</a></p>
    <div class="steps" id="steps"></div>
    <div class="two"><div id="main"></div><aside class="sticky" id="summary"></aside></div></div>`;

  const paintSteps = () => {
    $('#steps', root).innerHTML = ['Guest details', 'Review & confirm', 'Booking confirmed'].map((t, i) =>
      `<div class="step ${step === i + 1 ? 'on' : step > i + 1 ? 'done' : ''}"><i>${step > i + 1 ? '✓' : i + 1}</i>${t}</div>`).join('');
  };

  async function loadQuote(silent = false) {
    try {
      const r = await api('/bookings/quote', { method: 'POST', body: { roomId: input.roomId, checkIn: input.checkIn, checkOut: input.checkOut, rooms: input.rooms, coupon } });
      quote = r;
      const was = soldOut;
      soldOut = !r.canBook;
      if (silent && soldOut && !was) toast('This room was just booked by someone else.', 'error', 5000);
      return true;
    } catch (e) {
      if (!silent) throw e;
      return false;
    }
  }

  function paintSummary(couponMsg = '') {
    const p = quote.price;
    const freeUntil = addDays(input.checkIn, -2);
    $('#summary', root).innerHTML = `<div class="panel">
      ${img(hotel.image, hotel.name, '').replace('<img', '<img style="border-radius:10px;aspect-ratio:16/9;object-fit:cover;width:100%;margin-bottom:12px"')}
      <h3 style="margin-bottom:2px">${esc(hotel.name)}</h3>${stars(hotel.stars)}<p class="loc">${esc(hotel.city)}</p>
      <p style="margin:0"><b>${esc(room.name)}</b> × ${input.rooms}</p>
      <p class="muted small">${fmtDate(input.checkIn, { weekday: 'short', day: 'numeric', month: 'short' })} → ${fmtDate(input.checkOut, { weekday: 'short', day: 'numeric', month: 'short' })} · ${plural(nights, 'night')}<br>${plural(input.adults, 'adult')}${input.children ? ', ' + plural(input.children, 'child', 'children') : ''}</p>
      <hr style="border:0;border-top:1px solid var(--line);margin:12px 0">
      ${priceRows(p, { nights, rooms: input.rooms, pricePerNight: room.pricePerNight })}
      ${step < 3 ? `<div class="field" style="margin:14px 0 0"><label for="cpn">Have a coupon?</label>
        <div style="display:flex;gap:8px"><input id="cpn" value="${esc(coupon)}" placeholder="e.g. WELCOME10" style="text-transform:uppercase"><button class="btn btn-ghost" id="cpn-apply">${coupon ? 'Update' : 'Apply'}</button></div>
        ${couponMsg ? `<div class="err">${esc(couponMsg)}</div>` : p.coupon ? `<div class="small" style="color:var(--ok);margin-top:4px">✔ ${esc(p.coupon)} applied <a href="#" id="cpn-rm">remove</a></div>` : ''}</div>` : ''}
      <p class="muted small" style="margin:12px 0 0">${freeUntil >= todayISO() ? `Free cancellation until ${fmtDate(freeUntil, { day: 'numeric', month: 'short' })}.` : 'Cancellation is partly refundable for this date (50% one day before, none on arrival day).'}</p>
    </div></div>`;
    $('#cpn-apply', root)?.addEventListener('click', async (e) => {
      const val = $('#cpn', root).value.trim().toUpperCase();
      const prev = coupon; coupon = val;
      await busy(e.target, async () => {
        try { await loadQuote(); paintSummary(); if (val) toast(`Coupon ${val} applied`, 'success'); }
        catch (ex) { coupon = prev; paintSummary(ex.message); }
      });
    });
    $('#cpn-rm', root)?.addEventListener('click', async (e) => { e.preventDefault(); coupon = ''; await loadQuote(); paintSummary(); });
  }

  const err = (el, msg) => { el.classList.add('invalid'); const e = el.closest('.field').querySelector('.err'); if (e) { e.textContent = msg; e.hidden = false; } };

  function paintStep1() {
    step = 1; paintSteps();
    $('#main', root).innerHTML = `<div class="panel">
      <h2>Guest details</h2>
      ${soldOut ? `<div class="notice n-bad">Sorry, this room is no longer available for these dates. <a href="#/hotel/${hotel.id}?${qs({ checkIn: input.checkIn, checkOut: input.checkOut, adults: input.adults, children: input.children, rooms: input.rooms })}">Choose another room</a>.</div>` : ''}
      <p class="muted">The primary guest receives the booking confirmation and checks in at the hotel.</p>
      <form id="gform" novalidate>
        <div class="grid2"><div class="field"><label for="g-name">Full name *</label><input id="g-name" value="${esc(form.name)}" autocomplete="name"><div class="err" hidden></div></div>
          <div class="field"><label for="g-phone">Mobile number *</label><input id="g-phone" type="tel" value="${esc(form.phone)}" placeholder="10-digit number" autocomplete="tel"><div class="err" hidden></div></div></div>
        <div class="field"><label for="g-email">Email *</label><input id="g-email" type="email" value="${esc(form.email)}" autocomplete="email"><div class="err" hidden></div></div>
        ${extraCount ? `<h4 style="margin:18px 0 8px">Other guests <span class="muted small">(optional)</span></h4><div class="grid2">${form.others.map((n, i) => `<div class="field"><label for="g-o${i}">Guest ${i + 2} name</label><input id="g-o${i}" value="${esc(n)}"><div class="err" hidden></div></div>`).join('')}</div>` : ''}
        <div class="field"><label for="g-req">Special requests <span class="muted small">(optional, not guaranteed)</span></label><textarea id="g-req" maxlength="500" placeholder="Late check-in, high floor, extra pillows…">${esc(form.requests)}</textarea></div>
        <button class="btn btn-accent" type="submit" ${soldOut ? 'disabled' : ''}>Continue to review</button>
      </form></div>`;
    $('#gform', root).addEventListener('submit', (e) => {
      e.preventDefault();
      $$('.invalid', root).forEach((x) => x.classList.remove('invalid'));
      $$('.err', $('#gform', root)).forEach((x) => (x.hidden = true));
      const name = $('#g-name', root), phone = $('#g-phone', root), email = $('#g-email', root);
      let ok = true;
      if (name.value.trim().length < 2) { err(name, 'Enter the guest\'s full name'); ok = false; }
      if (!EMAIL.test(email.value.trim())) { err(email, 'Enter a valid email address'); ok = false; }
      if (!PHONE.test(phone.value.replace(/[\s-]/g, ''))) { err(phone, 'Enter a valid 10-digit Indian mobile number'); ok = false; }
      form.others = form.others.map((_, i) => $('#g-o' + i, root).value.trim());
      form.others.forEach((n, i) => { if (n && n.length < 2) { err($('#g-o' + i, root), 'Name is too short'); ok = false; } });
      if (!ok) { toast('Please fix the highlighted fields', 'error'); $('.invalid', root)?.focus(); return; }
      Object.assign(form, { name: name.value.trim(), email: email.value.trim(), phone: phone.value.replace(/[\s-]/g, ''), requests: $('#g-req', root).value.trim() });
      paintStep2();
    });
  }

  function paintStep2() {
    step = 2; paintSteps(); window.scrollTo({ top: 0, behavior: 'smooth' });
    $('#main', root).innerHTML = `<div class="panel">
      <h2>Review your booking</h2>
      <div id="rv-err"></div>
      <div class="grid2" style="margin-top:6px">
        <div><p class="muted small" style="margin:0">Check-in</p><b>${fmtDate(input.checkIn)}</b></div><div><p class="muted small" style="margin:0">Check-out</p><b>${fmtDate(input.checkOut)}</b></div>
        <div><p class="muted small" style="margin:0">Room</p><b>${esc(room.name)}</b> × ${input.rooms}</div><div><p class="muted small" style="margin:0">Guests</p><b>${plural(input.adults + input.children, 'guest')}</b></div>
        <div><p class="muted small" style="margin:0">Primary guest</p><b>${esc(form.name)}</b><br><span class="muted small">${esc(form.email)} · ${esc(form.phone)}</span></div>
        ${form.others.some(Boolean) ? `<div><p class="muted small" style="margin:0">Other guests</p>${form.others.filter(Boolean).map(esc).join(', ')}</div>` : ''}
      </div>
      ${form.requests ? `<p style="margin-top:12px"><b>Special requests:</b> ${esc(form.requests)}</p>` : ''}
      <div class="notice n-info">💳 You pay at the hotel. Nothing is charged online. Free cancellation up to 2 days before check-in.</div>
      <div style="display:flex;gap:10px;flex-wrap:wrap"><button class="btn btn-ghost" id="back">← Edit details</button>
        <button class="btn btn-accent" id="confirm" ${soldOut ? 'disabled' : ''}>Confirm booking · ${money(quote.price.total)}</button></div></div>`;
    $('#back', root).onclick = paintStep1;
    $('#confirm', root).onclick = (e) => busy(e.currentTarget, async () => {
      try {
        const guests = [{ name: form.name, email: form.email, phone: form.phone }, ...form.others.filter(Boolean).map((n) => ({ name: n }))];
        const r = await api('/bookings', { method: 'POST', body: { ...input, coupon, guests, specialRequests: form.requests } });
        toast(`Booking confirmed! Your ID is ${r.booking.ref}`, 'success', 5000);
        location.hash = `#/booking/${r.booking.ref}?new=1`;
      } catch (ex) {
        if (ex.status === 409) {
          await loadQuote(true); paintSummary();
          $('#rv-err', root).innerHTML = `<div class="notice n-bad"><b>${esc(ex.message)}</b><br><a href="#/hotel/${hotel.id}?${qs({ checkIn: input.checkIn, checkOut: input.checkOut, adults: input.adults, children: input.children, rooms: input.rooms })}">See other rooms and dates</a></div>`;
          $('#confirm', root).disabled = true;
        } else if (ex.status === 401) { showAuth('login', 'Your session expired. Please log in to finish booking.'); }
        else toast(ex.message, 'error', 5000);
      }
    });
  }

  try { await loadQuote(); } catch (e) {
    $('#main', root).innerHTML = `<div class="notice n-bad">${esc(e.message)}</div><a class="btn btn-primary" href="#/hotels">Back to hotels</a>`;
    return;
  }
  paintSummary(); paintStep1();

  // keep the price/availability fresh while the guest fills in the form
  const off = bus.on('availability', async (e) => {
    if (e.roomId && e.roomId !== input.roomId) return;
    const was = soldOut;
    if (await loadQuote(true)) { paintSummary(); if (soldOut !== was) (step === 1 ? paintStep1 : paintStep2)(); }
  });
  return off;
}
