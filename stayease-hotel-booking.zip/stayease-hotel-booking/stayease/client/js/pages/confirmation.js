import { api } from '../api.js';
import { $, esc, money, img, toast, fmtDate, fmtDateTime } from '../ui.js';
import { session } from '../session.js';
import { showAuth } from '../auth.js';
import { bookingDetailsHTML, cancelFlow, statusBadge } from '../components.js';

export async function render(root, { params, args, reload }) {
  if (!session.user) {
    root.innerHTML = `<div class="container page-pad"><div class="empty"><div class="big">🔐</div><h2>Log in to view this booking</h2><button class="btn btn-primary" id="li">Log in</button></div></div>`;
    $('#li', root).onclick = () => showAuth('login');
    return;
  }
  let b;
  try { b = (await api('/bookings/' + args[0])).booking; } catch (e) {
    root.innerHTML = `<div class="container page-pad"><div class="empty"><div class="big">🔍</div><h2>${e.status === 404 ? 'Booking not found' : 'Could not load booking'}</h2><p class="muted">${esc(e.message)}</p><a class="btn btn-primary" href="#/my-bookings">My bookings</a></div></div>`;
    return;
  }
  const fresh = params.get('new') === '1' && b.status === 'CONFIRMED';
  root.innerHTML = `<div class="container page-pad fade-in" style="max-width:860px">
    <div class="panel">
      <div class="${fresh ? 'confirm' : ''}" style="${fresh ? '' : 'padding:6px 0 10px'}">
        ${fresh ? `<svg class="tick" viewBox="0 0 90 90" aria-hidden="true"><circle cx="45" cy="45" r="40"/><path d="M27 47l12 12 25-27"/></svg><h1 style="font-size:2rem">You're booked!</h1><p class="muted">A confirmation for ${esc(b.guests[0].email)} is saved in My bookings.</p>` : `<h1 style="font-size:1.8rem">Booking details</h1>`}
        <div class="refbox"><span class="muted small">Booking ID</span><code id="ref">${esc(b.ref)}</code><button class="btn btn-ghost btn-sm no-print" id="copy">Copy</button></div>
        <div>${statusBadge(b)}</div>
      </div>
      <div style="display:grid;grid-template-columns:150px 1fr;gap:16px;align-items:center;margin-top:14px">${img(b.hotel.image, b.hotel.name, '').replace('<img', '<img style="border-radius:10px;aspect-ratio:4/3;object-fit:cover;width:100%"')}
        <div><h2 style="margin:0">${esc(b.hotel.name)}</h2><p class="muted" style="margin:0">${esc(b.hotel.city)} · ${esc(b.room.name)}</p></div></div>
      ${bookingDetailsHTML(b)}
      <div class="no-print" style="display:flex;gap:10px;flex-wrap:wrap;margin-top:18px">
        <button class="btn btn-primary" id="print">Print / save PDF</button>
        <a class="btn btn-ghost" href="#/my-bookings">My bookings</a>
        ${b.canCancel ? '<button class="btn btn-danger" id="cancel">Cancel booking</button>' : ''}
        <a class="btn btn-ghost" href="#/hotels">Book another stay</a></div>
    </div></div>`;
  $('#copy', root).onclick = async () => { try { await navigator.clipboard.writeText(b.ref); toast('Booking ID copied', 'success', 2000); } catch { toast('Copy failed. Select the ID manually.', 'error'); } };
  $('#print', root).onclick = () => window.print();
  $('#cancel', root)?.addEventListener('click', () => cancelFlow(b, () => reload()));
}
