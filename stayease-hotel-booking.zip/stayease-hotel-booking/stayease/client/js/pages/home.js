import { api } from '../api.js';
import { $, $$, esc, money, img, plural, skeletonCards, amenityChips, stars, ratingBadge } from '../ui.js';
import { getSearch, setSearch } from '../state.js';
import { searchBoxHTML, bindSearchBox, getCities } from '../components.js';

const HERO = 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1800&q=70';

export async function render(root) {
  const s = getSearch();
  root.innerHTML = `
  <section class="hero" style="--hero:url('${HERO}')">
    <div class="container fade-in">
      <h1>Find a room that fits the trip.</h1>
      <p>Compare real prices, check live room availability and book in a couple of minutes. Free cancellation on most stays.</p>
      <div id="sb-wrap">${searchBoxHTML(s)}</div>
      <div class="stats" id="stats"></div>
    </div>
  </section>
  <section class="section"><div class="container">
    <div class="section-head"><div><h2>Popular destinations</h2><p class="muted">Tap a city to see what's open for your dates.</p></div></div>
    <div class="dests" id="dests">${skeletonCards(4, 190)}</div></div></section>
  <section class="section" style="padding-top:0"><div class="container">
    <div class="section-head"><div><h2>Top-rated stays</h2><p class="muted">Guest favourites right now.</p></div><a class="btn btn-ghost" href="#/hotels?sort=rating">See all hotels</a></div>
    <div class="dests" id="top">${skeletonCards(4, 250)}</div></div></section>
  <section class="section" style="padding-top:0"><div class="container">
    <div class="section-head"><div><h2>Offers you can use today</h2><p class="muted">Enter a code on the booking page.</p></div></div>
    <div class="offers" id="offers"></div></div></section>
  <section class="section" style="background:#fff"><div class="container"><div class="features">
    <div class="feature"><div class="ic">🔒</div><h3>No double bookings</h3><p class="muted">Rooms are locked the moment you confirm, so what you book is yours.</p></div>
    <div class="feature"><div class="ic">⚡</div><h3>Live availability</h3><p class="muted">If the last room goes, you see it change on screen instantly.</p></div>
    <div class="feature"><div class="ic">🧾</div><h3>Clear pricing</h3><p class="muted">Nights, discounts and GST are itemised before you confirm.</p></div>
    <div class="feature"><div class="ic">↩️</div><h3>Easy cancellation</h3><p class="muted">Cancel from My bookings. Full refund up to 2 days before check-in.</p></div>
  </div></div></section>`;

  const unbind = bindSearchBox(root, s, (v) => {
    setSearch(v);
    location.hash = '#/hotels?' + new URLSearchParams({ q: v.q, checkIn: v.checkIn, checkOut: v.checkOut, adults: v.adults, children: v.children, rooms: v.rooms });
  });

  try {
    const [cities, top, coupons] = await Promise.all([getCities(), api('/hotels?sort=rating&limit=4'), api('/coupons')]);
    $('#stats', root).innerHTML = `<span>🏨 ${top.total}+ hotels</span><span>📍 ${plural(cities.length, 'city', 'cities')}</span><span>🛏️ Instant confirmation</span>`;
    $('#dests', root).innerHTML = cities.slice(0, 8).map((c) => `
      <button class="dest" data-city="${esc(c.city)}">${img(c.image, c.city)}
        <div class="dest-in"><strong>${esc(c.city)}</strong><span class="small">${plural(c.hotels, 'hotel')} · from ${money(c.fromPrice)}</span></div></button>`).join('');
    $$('.dest', root).forEach((b) => (b.onclick = () => {
      const cur = setSearch({ q: b.dataset.city });
      location.hash = '#/hotels?' + new URLSearchParams({ q: cur.q, checkIn: cur.checkIn, checkOut: cur.checkOut, adults: cur.adults, children: cur.children, rooms: cur.rooms });
    }));
    $('#top', root).innerHTML = top.hotels.map((h) => `
      <a class="dest" href="#/hotel/${h.id}?${new URLSearchParams({ checkIn: s.checkIn, checkOut: s.checkOut, adults: s.adults, children: s.children, rooms: s.rooms })}" style="text-decoration:none">
        ${img(h.image, h.name)}<div class="dest-in"><strong>${esc(h.name)}</strong>
        <span class="small">${esc(h.city)} · ★ ${h.rating?.toFixed(1) ?? '–'} · from ${money(h.fromPrice)}</span></div></a>`).join('');
    $('#offers', root).innerHTML = coupons.coupons.map((c) => `<div class="offer"><code>${esc(c.code)}</code><p>${esc(c.label)}</p></div>`).join('')
      + `<div class="offer"><code>LONG STAY</code><p>Automatic: 5% off 3+ nights, 10% off 5+, 15% off 7+.</p></div>`;
  } catch (e) {
    $('#dests', root).innerHTML = `<div class="empty" style="grid-column:1/-1"><p class="muted">${esc(e.message)}</p><button class="btn btn-primary" id="retry">Try again</button></div>`;
    $('#top', root).innerHTML = '';
    $('#retry', root).onclick = () => render(root);
  }
  return unbind;
}
