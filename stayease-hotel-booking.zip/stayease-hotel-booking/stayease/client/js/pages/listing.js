import { api, qs } from '../api.js';
import { $, $$, esc, money, img, plural, stars, ratingBadge, amenityChips, AMENITY, skeletonCards, emptyState, errorState, debounce, fmtDate } from '../ui.js';
import { getSearch, setSearch, searchFromParams } from '../state.js';
import { searchBoxHTML, bindSearchBox } from '../components.js';

const FILTER_AMENITIES = ['wifi', 'pool', 'breakfast', 'parking', 'spa', 'gym', 'restaurant', 'ac'];
const SORTS = [['popular', 'Recommended'], ['price_asc', 'Price: low to high'], ['price_desc', 'Price: high to low'], ['rating', 'Guest rating'], ['stars', 'Star rating']];

export async function render(root, { params }) {
  let s = searchFromParams(params);
  const f = {
    minPrice: params.get('minPrice') || '', maxPrice: params.get('maxPrice') || '',
    stars: new Set((params.get('stars') || '').split(',').filter(Boolean)),
    minRating: params.get('minRating') || '', amenities: new Set((params.get('amenities') || '').split(',').filter(Boolean)),
    sort: params.get('sort') || 'popular', page: 1,
  };
  let bounds = null, loadId = 0;

  root.innerHTML = `
  <section class="page-head"><div class="container">${searchBoxHTML(s)}</div></section>
  <div class="container listing">
    <aside class="filters" id="filters" aria-label="Filters">
      <div style="display:flex;justify-content:space-between;align-items:center"><strong>Filters</strong><button class="btn btn-ghost btn-sm" id="clear">Clear all</button></div>
      <h4>Price per night (₹)</h4>
      <div class="grid2"><input id="f-min" type="number" min="0" placeholder="Min" inputmode="numeric" value="${esc(f.minPrice)}" aria-label="Minimum price"><input id="f-max" type="number" min="0" placeholder="Max" inputmode="numeric" value="${esc(f.maxPrice)}" aria-label="Maximum price"></div>
      <p class="muted small" id="f-bounds"></p>
      <h4>Star rating</h4>
      ${[5, 4, 3].map((n) => `<label class="check"><input type="checkbox" data-star="${n}" ${f.stars.has(String(n)) ? 'checked' : ''}> <span class="stars">${'★'.repeat(n)}</span> ${n} star</label>`).join('')}
      <h4>Guest rating</h4>
      <select id="f-rating" aria-label="Minimum guest rating">${[['', 'Any'], ['3.5', '3.5+'], ['4', '4.0+'], ['4.3', '4.3+'], ['4.5', '4.5+']].map(([v, l]) => `<option value="${v}" ${f.minRating === v ? 'selected' : ''}>${l}</option>`).join('')}</select>
      <h4>Amenities</h4>
      ${FILTER_AMENITIES.map((a) => `<label class="check"><input type="checkbox" data-am="${a}" ${f.amenities.has(a) ? 'checked' : ''}> ${AMENITY[a][0]} ${AMENITY[a][1]}</label>`).join('')}
    </aside>
    <section class="results">
      <div class="results-bar">
        <div><h2 id="res-title" style="margin:0">Searching…</h2><p class="muted small" id="res-sub" style="margin:0"></p></div>
        <div style="display:flex;gap:8px;align-items:center"><button class="btn btn-ghost filter-toggle" id="ftoggle">Filters</button>
          <label class="muted small" for="sort" style="margin:0">Sort by</label>
          <select id="sort">${SORTS.map(([v, l]) => `<option value="${v}" ${f.sort === v ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
      </div>
      <div class="cards" id="cards">${skeletonCards(3)}</div>
      <div class="center" id="more" style="margin-top:18px"></div>
    </section>
  </div>`;

  const sub = () => `${fmtDate(s.checkIn, { day: 'numeric', month: 'short' })} – ${fmtDate(s.checkOut, { day: 'numeric', month: 'short' })} · ${plural(s.adults + s.children, 'guest')} · ${plural(s.rooms, 'room')}`;
  const linkQs = () => qs({ checkIn: s.checkIn, checkOut: s.checkOut, adults: s.adults, children: s.children, rooms: s.rooms });

  const syncUrl = () => {
    const q = qs({ q: s.q, checkIn: s.checkIn, checkOut: s.checkOut, adults: s.adults, children: s.children, rooms: s.rooms,
      minPrice: f.minPrice, maxPrice: f.maxPrice, stars: [...f.stars].join(','), minRating: f.minRating, amenities: [...f.amenities].join(','), sort: f.sort === 'popular' ? '' : f.sort });
    history.replaceState(null, '', '#/hotels?' + q);
  };

  const card = (h) => `
    <article class="hcard fade-in">
      <a class="hcard-img" href="#/hotel/${h.id}?${linkQs()}" aria-label="View ${esc(h.name)}">${img(h.image, h.name)}
        ${h.roomsLeft != null && h.roomsLeft <= 3 ? `<span class="tag">Only ${h.roomsLeft} left!</span>` : ''}</a>
      <div class="hcard-body">
        <div><h3 style="margin-bottom:2px"><a href="#/hotel/${h.id}?${linkQs()}">${esc(h.name)}</a></h3>${stars(h.stars)}
          <p class="loc">📍 ${esc(h.address ? h.address + ', ' : '')}${esc(h.city)}</p>
          <div class="chips">${amenityChips(h.amenities, 5)}</div><p class="clamp">${esc(h.description)}</p></div>
        <div class="hcard-side">${ratingBadge(h.rating, h.reviewCount)}
          <div><span class="muted small">from</span><div class="price">${money(h.fromPrice)}</div><span class="muted small">per room, per night<br>+ taxes</span></div>
          <a class="btn btn-accent btn-sm" href="#/hotel/${h.id}?${linkQs()}">View rooms</a></div>
      </div>
    </article>`;

  async function load(reset = true) {
    const id = ++loadId;
    const cards = $('#cards', root), more = $('#more', root);
    if (reset) { f.page = 1; cards.innerHTML = skeletonCards(3); more.innerHTML = ''; $('#res-title', root).textContent = 'Searching…'; }
    syncUrl();
    try {
      const data = await api('/hotels?' + qs({
        q: s.q, checkIn: s.checkIn, checkOut: s.checkOut, guests: s.adults + s.children, rooms: s.rooms,
        minPrice: f.minPrice, maxPrice: f.maxPrice, stars: [...f.stars].join(','), minRating: f.minRating,
        amenities: [...f.amenities].join(','), sort: f.sort, page: f.page, limit: 6 }));
      if (id !== loadId) return; // a newer search replaced this one
      bounds = data.priceBounds;
      $('#f-bounds', root).textContent = bounds.max ? `Available from ${money(bounds.min)} to ${money(bounds.max)}` : '';
      $('#res-title', root).textContent = `${s.q ? s.q + ': ' : ''}${plural(data.total, 'property', 'properties')} available`;
      $('#res-sub', root).textContent = sub();
      if (!data.total) {
        cards.innerHTML = emptyState('🔎', 'No hotels match your search', 'Try different dates, fewer filters or another destination.',
          '<button class="btn btn-primary" id="empty-clear">Clear filters</button>');
        $('#empty-clear', root).onclick = clearAll;
        return;
      }
      const html = data.hotels.map(card).join('');
      if (reset) cards.innerHTML = html; else cards.insertAdjacentHTML('beforeend', html);
      more.innerHTML = data.page < data.pages ? `<button class="btn btn-ghost" id="load-more">Show more hotels (${data.total - data.page * 6} left)</button>` : '';
      $('#load-more', root)?.addEventListener('click', () => { f.page++; load(false); });
    } catch (e) {
      if (id !== loadId) return;
      cards.innerHTML = errorState(e.message);
      $('[data-retry]', cards).onclick = () => load(true);
    }
  }

  function clearAll() {
    Object.assign(f, { minPrice: '', maxPrice: '', minRating: '', sort: 'popular' });
    f.stars.clear(); f.amenities.clear();
    $('#f-min', root).value = ''; $('#f-max', root).value = ''; $('#f-rating', root).value = ''; $('#sort', root).value = 'popular';
    $$('#filters input[type=checkbox]', root).forEach((c) => (c.checked = false));
    load();
  }

  const unbind = bindSearchBox(root, s, (v) => { s = setSearch(v); load(); });
  const price = debounce(() => { f.minPrice = $('#f-min', root).value; f.maxPrice = $('#f-max', root).value; load(); });
  $('#f-min', root).oninput = price; $('#f-max', root).oninput = price;
  $$('[data-star]', root).forEach((c) => (c.onchange = () => { c.checked ? f.stars.add(c.dataset.star) : f.stars.delete(c.dataset.star); load(); }));
  $$('[data-am]', root).forEach((c) => (c.onchange = () => { c.checked ? f.amenities.add(c.dataset.am) : f.amenities.delete(c.dataset.am); load(); }));
  $('#f-rating', root).onchange = (e) => { f.minRating = e.target.value; load(); };
  $('#sort', root).onchange = (e) => { f.sort = e.target.value; load(); };
  $('#clear', root).onclick = clearAll;
  $('#ftoggle', root).onclick = () => $('#filters', root).classList.toggle('open');

  load();
  return unbind;
}
