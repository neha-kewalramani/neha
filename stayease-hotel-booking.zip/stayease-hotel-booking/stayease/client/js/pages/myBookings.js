import { api } from '../api.js';
import { $, $$, esc, money, img, plural, toast, fmtDate, openModal, closeModal, busy, skeletonCards, emptyState, errorState } from '../ui.js';
import { session } from '../session.js';
import { showAuth } from '../auth.js';
import { bookingDetailsHTML, cancelFlow, statusBadge } from '../components.js';

export async function render(root) {
  if (!session.user) {
    root.innerHTML = `<div class="container page-pad"><div class="empty"><div class="big">🔐</div><h2>Log in to see your bookings</h2><button class="btn btn-primary" id="li">Log in</button></div></div>`;
    $('#li', root).onclick = () => showAuth('login');
    showAuth('login');
    return;
  }
  let tab = 'upcoming', all = [];
  root.innerHTML = `<div class="container page-pad"><h1 style="font-size:2rem">My bookings</h1><div class="tabs" id="tabs"></div><div id="list">${skeletonCards(2, 150)}</div></div>`;

  const groups = () => ({
    upcoming: all.filter((b) => b.phase === 'upcoming' || b.phase === 'ongoing'),
    past: all.filter((b) => b.phase === 'past'),
    cancelled: all.filter((b) => b.phase === 'cancelled'),
  });

  function paint() {
    const g = groups();
    $('#tabs', root).innerHTML = [['upcoming', 'Upcoming'], ['past', 'Past'], ['cancelled', 'Cancelled']]
      .map(([k, l]) => `<button class="tab ${tab === k ? 'on' : ''}" data-tab="${k}">${l}<small>${g[k].length}</small></button>`).join('');
    $$('[data-tab]', root).forEach((b) => (b.onclick = () => { tab = b.dataset.tab; paint(); }));
    const rows = g[tab];
    $('#list', root).innerHTML = rows.length ? rows.map((b) => `
      <article class="bcard fade-in" data-ref="${b.ref}">
        ${img(b.hotel.image, b.hotel.name)}
        <div><div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap"><h3 style="margin:0">${esc(b.hotel.name)}</h3>${statusBadge(b)}</div>
          <p class="muted" style="margin:2px 0 8px">${esc(b.hotel.city)} · ${esc(b.room.name)} × ${b.rooms}</p>
          <p style="margin:0">📅 <b>${fmtDate(b.checkIn, { weekday: 'short', day: 'numeric', month: 'short' })}</b> → <b>${fmtDate(b.checkOut, { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' })}</b> · ${plural(b.nights, 'night')}</p>
          <p style="margin:2px 0">👥 ${plural(b.adults + b.children, 'guest')} · Total <b>${money(b.pricing.total)}</b>${b.status === 'CANCELLED' ? ` · Refund ${money(b.pricing.refund)}` : ''}</p>
          <p class="muted small" style="margin:6px 0 0">Booking ID <b style="color:var(--ink);letter-spacing:.04em">${esc(b.ref)}</b></p></div>
        <div class="acts">
          <button class="btn btn-ghost btn-sm" data-act="view">View details</button>
          ${b.canCancel ? '<button class="btn btn-danger btn-sm" data-act="cancel">Cancel</button>' : ''}
          ${b.phase === 'past' && !b.reviewed ? '<button class="btn btn-accent btn-sm" data-act="review">Write review</button>' : ''}
          ${b.phase === 'past' && b.reviewed ? '<span class="badge b-ok" style="text-align:center">Reviewed ✓</span>' : ''}
          ${b.phase === 'past' || b.phase === 'cancelled' ? `<a class="btn btn-ghost btn-sm" href="#/hotel/${b.hotel.id}">Book again</a>` : ''}
        </div></article>`).join('')
      : emptyState(tab === 'upcoming' ? '🧳' : tab === 'past' ? '🕰️' : '✅', `No ${tab} bookings`,
        tab === 'upcoming' ? 'Your next trip will show up here.' : tab === 'past' ? 'Completed stays will appear here.' : 'You have not cancelled any bookings.',
        tab === 'upcoming' ? '<a class="btn btn-primary" href="#/hotels">Find a hotel</a>' : '');
    $$('.bcard', root).forEach((card) => {
      const b = all.find((x) => x.ref === card.dataset.ref);
      card.querySelector('[data-act=view]').onclick = () => openModal(`<h3>Booking ${esc(b.ref)} ${statusBadge(b)}</h3>${bookingDetailsHTML(b)}`, { wide: true });
      card.querySelector('[data-act=cancel]')?.addEventListener('click', () => cancelFlow(b, () => load()));
      card.querySelector('[data-act=review]')?.addEventListener('click', () => reviewModal(b));
    });
  }

  function reviewModal(b) {
    let rating = 0;
    const m = openModal(`<h3>Review ${esc(b.hotel.name)}</h3><p class="muted">How was your stay on ${fmtDate(b.checkIn, { day: 'numeric', month: 'short' })}?</p>
      <div class="starpick" id="sp" role="radiogroup" aria-label="Rating">${[1, 2, 3, 4, 5].map((n) => `<span data-n="${n}" role="radio" aria-checked="false" tabindex="0">★</span>`).join('')}</div>
      <div class="field" style="margin-top:12px"><label for="rv">Your review</label><textarea id="rv" maxlength="600" placeholder="What did you like? Anything to improve?"></textarea></div>
      <div class="notice n-bad" id="rv-err" hidden></div><button class="btn btn-primary btn-block" id="rv-go">Submit review</button>`);
    const paintStars = () => $$('#sp span', m).forEach((s) => { s.classList.toggle('on', Number(s.dataset.n) <= rating); s.setAttribute('aria-checked', String(Number(s.dataset.n) === rating)); });
    $$('#sp span', m).forEach((s) => {
      s.onclick = () => { rating = Number(s.dataset.n); paintStars(); };
      s.onkeydown = (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); s.click(); } };
    });
    $('#rv-go', m).onclick = (e) => busy(e.currentTarget, async () => {
      const err = $('#rv-err', m); err.hidden = true;
      if (!rating) { err.textContent = 'Please choose a star rating'; err.hidden = false; return; }
      try {
        await api(`/hotels/${b.hotel.id}/reviews`, { method: 'POST', body: { bookingId: b.id, rating, comment: $('#rv', m).value } });
        closeModal(); toast('Thanks for your review!', 'success'); load();
      } catch (ex) { err.textContent = ex.message; err.hidden = false; }
    });
  }

  async function load() {
    try { all = (await api('/bookings/mine')).bookings; paint(); }
    catch (e) { $('#list', root).innerHTML = errorState(e.message); $('[data-retry]', root).onclick = load; }
  }
  await load();
}
