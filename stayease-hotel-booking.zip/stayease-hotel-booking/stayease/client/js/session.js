// Who is logged in? Keeps the current user and lets pages react when it changes.
import { api, token } from './api.js';
export const session = { user: null, listeners: [] };
export const onSession = (fn) => session.listeners.push(fn);
const emit = () => session.listeners.forEach((f) => f(session.user));

export async function loadUser() {
  if (!token.get()) { session.user = null; return; }
  try { session.user = (await api('/auth/me')).user; } catch { token.clear(); session.user = null; }
}
export function setSession({ token: t, user }) { token.set(t); session.user = user; emit(); }
export function logout() { token.clear(); session.user = null; emit(); }
export const isAdmin = () => session.user?.role === 'admin';
