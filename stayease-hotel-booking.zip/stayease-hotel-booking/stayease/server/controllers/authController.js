const db = require('../db/database');
const ApiError = require('../utils/ApiError');
const v = require('../middleware/validate');
const { signToken, hashPassword, checkPassword } = require('../middleware/auth');

exports.register = (req, res) => {
  const name = v.str(req.body.name, 'Name', { min: 2, max: 60 });
  const email = v.email(req.body.email);
  const password = v.str(req.body.password, 'Password', { min: 6, max: 100 });
  if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(email))
    throw new ApiError(409, 'An account with this email already exists. Try logging in instead.');
  const info = db.prepare('INSERT INTO users (name, email, password_hash) VALUES (?,?,?)').run(name, email, hashPassword(password));
  const user = { id: Number(info.lastInsertRowid), name, email, role: 'user' };
  res.status(201).json({ token: signToken(user), user });
};

exports.login = (req, res) => {
  const email = v.email(req.body.email);
  const password = v.str(req.body.password, 'Password', { max: 100 });
  const row = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!row || !checkPassword(password, row.password_hash)) throw new ApiError(401, 'Incorrect email or password');
  const user = { id: row.id, name: row.name, email: row.email, role: row.role };
  res.json({ token: signToken(user), user });
};

exports.me = (req, res) => res.json({ user: req.user });
