const db = require('../db/database');
const ApiError = require('../utils/ApiError');
const v = require('../middleware/validate');
const { validateStay, today } = require('../utils/dates');
const { bulkAvailability, roomAvailability } = require('../utils/availability');
const { calculatePrice } = require('../utils/pricing');
const { broadcast } = require('../utils/events');

const AMENITIES = ['wifi', 'pool', 'parking', 'breakfast', 'spa', 'gym', 'restaurant', 'bar', 'ac', 'pet', 'shuttle', 'laundry'];

const HOTEL_SELECT = `SELECT h.*,
  (SELECT ROUND(AVG(rating), 1) FROM reviews r WHERE r.hotel_id = h.id) AS rating,
  (SELECT COUNT(*) FROM reviews r WHERE r.hotel_id = h.id) AS review_count
  FROM hotels h`;

const shapeHotel = (h) => ({
  id: h.id, name: h.name, city: h.city, state: h.state, address: h.address, description: h.description,
  stars: h.stars, image: h.image, gallery: JSON.parse(h.gallery || '[]'), amenities: JSON.parse(h.amenities || '[]'),
  active: !!h.active, rating: h.rating || null, reviewCount: h.review_count || 0,
});
const shapeRoom = (r) => ({
  id: r.id, hotelId: r.hotel_id, name: r.name, type: r.type, pricePerNight: r.price_per_night, capacity: r.capacity,
  totalUnits: r.total_units, beds: r.beds, sizeSqm: r.size_sqm, image: r.image,
  amenities: JSON.parse(r.amenities || '[]'), active: !!r.active,
});
exports.shapeHotel = shapeHotel;
exports.shapeRoom = shapeRoom;
exports.AMENITIES = AMENITIES;

// GET /api/hotels  — search + filters + sorting + pagination, availability-aware.
exports.list = (req, res) => {
  const q = req.query;
  const guests = v.int(q.guests, 'Guests', 1, 60, 2);
  const roomsWanted = v.int(q.rooms, 'Rooms', 1, 9, 1);
  const page = v.int(q.page, 'Page', 1, 1000, 1);
  const limit = v.int(q.limit, 'Limit', 1, 50, 8);
  const hasDates = !!(q.checkIn && q.checkOut);
  const nights = hasDates ? validateStay(q.checkIn, q.checkOut) : 0;
  const avail = hasDates ? bulkAvailability(q.checkIn, q.checkOut) : null;

  let sql = `${HOTEL_SELECT} WHERE h.active = 1`;
  const args = [];
  const text = String(q.q || '').trim();
  if (text) {
    sql += ' AND (h.city LIKE ? OR h.state LIKE ? OR h.name LIKE ? OR h.address LIKE ?)';
    args.push(...Array(4).fill(`%${text}%`));
  }
  const hotels = db.prepare(sql).all(...args);

  const roomsByHotel = new Map();
  for (const r of db.prepare('SELECT * FROM rooms WHERE active = 1').all()) {
    if (!roomsByHotel.has(r.hotel_id)) roomsByHotel.set(r.hotel_id, []);
    roomsByHotel.get(r.hotel_id).push(r);
  }

  const stars = String(q.stars || '').split(',').filter(Boolean).map(Number);
  const needAmenities = String(q.amenities || '').split(',').filter(Boolean);
  const minRating = Number(q.minRating) || 0;

  let items = [];
  for (const h of hotels) {
    // keep only rooms that fit the party and are free on the chosen dates
    const eligible = (roomsByHotel.get(h.id) || [])
      .filter((r) => r.capacity * roomsWanted >= guests && (!avail || (avail.get(r.id) || 0) >= roomsWanted))
      .sort((a, b) => a.price_per_night - b.price_per_night);
    if (!eligible.length) continue;
    const s = shapeHotel(h);
    const cheapest = eligible[0];
    items.push({
      ...s, fromPrice: cheapest.price_per_night,
      roomsLeft: avail ? avail.get(cheapest.id) : null,
      roomTypes: eligible.length,
    });
  }

  // price slider bounds are computed before the price filter is applied
  const prices = items.map((i) => i.fromPrice);
  const bounds = { min: prices.length ? Math.min(...prices) : 0, max: prices.length ? Math.max(...prices) : 0 };

  if (q.minPrice) items = items.filter((i) => i.fromPrice >= Number(q.minPrice));
  if (q.maxPrice) items = items.filter((i) => i.fromPrice <= Number(q.maxPrice));
  if (stars.length) items = items.filter((i) => stars.includes(i.stars));
  if (minRating) items = items.filter((i) => (i.rating || 0) >= minRating);
  if (needAmenities.length) items = items.filter((i) => needAmenities.every((a) => i.amenities.includes(a)));

  const sorters = {
    price_asc: (a, b) => a.fromPrice - b.fromPrice,
    price_desc: (a, b) => b.fromPrice - a.fromPrice,
    rating: (a, b) => (b.rating || 0) - (a.rating || 0) || b.reviewCount - a.reviewCount,
    stars: (a, b) => b.stars - a.stars || (b.rating || 0) - (a.rating || 0),
    popular: (a, b) => (b.rating || 3) * 20 + b.reviewCount - ((a.rating || 3) * 20 + a.reviewCount),
  };
  items.sort(sorters[q.sort] || sorters.popular);

  const total = items.length;
  res.json({
    total, page, pages: Math.max(1, Math.ceil(total / limit)), nights, priceBounds: bounds,
    hotels: items.slice((page - 1) * limit, page * limit),
  });
};

// GET /api/hotels/cities — for destination suggestions and "popular destinations"
exports.cities = (req, res) => {
  const rows = db.prepare(`SELECT h.city, h.state, COUNT(DISTINCT h.id) AS hotels, MIN(r.price_per_night) AS fromPrice,
      (SELECT image FROM hotels x WHERE x.city = h.city AND x.active = 1 ORDER BY x.stars DESC LIMIT 1) AS image
    FROM hotels h JOIN rooms r ON r.hotel_id = h.id AND r.active = 1
    WHERE h.active = 1 GROUP BY h.city ORDER BY hotels DESC, h.city`).all();
  res.json({ cities: rows });
};

// GET /api/hotels/:id  (?checkIn&checkOut&rooms&guests adds live availability + price per room)
exports.getOne = (req, res) => {
  const h = db.prepare(`${HOTEL_SELECT} WHERE h.id = ?`).get(req.params.id);
  if (!h || (!h.active && req.user?.role !== 'admin')) throw new ApiError(404, 'Hotel not found');
  const q = req.query;
  const roomsWanted = v.int(q.rooms, 'Rooms', 1, 9, 1);
  const guests = v.int(q.guests, 'Guests', 1, 60, 2);
  const hasDates = !!(q.checkIn && q.checkOut);
  const nights = hasDates ? validateStay(q.checkIn, q.checkOut) : 0;

  const rooms = db.prepare('SELECT * FROM rooms WHERE hotel_id = ? AND active = 1 ORDER BY price_per_night').all(h.id).map((r) => {
    const room = shapeRoom(r);
    room.fits = r.capacity * roomsWanted >= guests;
    if (hasDates) {
      room.available = roomAvailability(r.id, q.checkIn, q.checkOut);
      room.quote = calculatePrice({ pricePerNight: r.price_per_night, nights, rooms: roomsWanted });
    }
    return room;
  });

  const breakdown = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
  db.prepare('SELECT rating, COUNT(*) AS c FROM reviews WHERE hotel_id = ? GROUP BY rating').all(h.id)
    .forEach((r) => { breakdown[r.rating] = r.c; });
  const reviews = db.prepare(`SELECT v.id, v.rating, v.comment, v.created_at AS createdAt, u.name AS author
    FROM reviews v JOIN users u ON u.id = v.user_id WHERE v.hotel_id = ? ORDER BY v.created_at DESC LIMIT 12`).all(h.id);
  res.json({ hotel: shapeHotel(h), rooms, nights, reviews, ratingBreakdown: breakdown });
};

exports.reviewsOf = (req, res) => {
  const rows = db.prepare(`SELECT v.id, v.rating, v.comment, v.created_at AS createdAt, u.name AS author
    FROM reviews v JOIN users u ON u.id = v.user_id WHERE v.hotel_id = ? ORDER BY v.created_at DESC`).all(req.params.id);
  res.json({ reviews: rows });
};

// POST /api/hotels/:id/reviews — only guests who finished a stay can review it (once per booking)
exports.addReview = (req, res) => {
  const rating = v.int(req.body.rating, 'Rating', 1, 5);
  const comment = v.str(req.body.comment, 'Review', { min: 5, max: 600 });
  const bookingId = v.int(req.body.bookingId, 'Booking', 1, 1e9);
  const b = db.prepare('SELECT * FROM bookings WHERE id = ? AND user_id = ? AND hotel_id = ?').get(bookingId, req.user.id, req.params.id);
  if (!b || b.status !== 'CONFIRMED') throw new ApiError(403, 'You can only review hotels you have stayed at');
  if (b.check_out > today()) throw new ApiError(403, 'You can write a review after your stay is complete');
  if (db.prepare('SELECT 1 FROM reviews WHERE booking_id = ?').get(b.id)) throw new ApiError(409, 'You have already reviewed this stay');
  const info = db.prepare('INSERT INTO reviews (hotel_id, user_id, booking_id, rating, comment) VALUES (?,?,?,?,?)')
    .run(b.hotel_id, req.user.id, b.id, rating, comment);
  res.status(201).json({ id: Number(info.lastInsertRowid), message: 'Thanks for your review!' });
};

// ---------- Admin CRUD ----------
function parseHotel(b) {
  return {
    name: v.str(b.name, 'Hotel name', { min: 2, max: 120 }),
    city: v.str(b.city, 'City', { min: 2, max: 60 }),
    state: v.str(b.state, 'State', { optional: true, max: 60 }),
    address: v.str(b.address, 'Address', { optional: true, max: 200 }),
    description: v.str(b.description, 'Description', { optional: true, max: 1500 }),
    stars: v.int(b.stars, 'Star rating', 1, 5),
    image: v.url(b.image, 'Main image URL'),
    gallery: JSON.stringify(v.list(b.gallery, 'Gallery', null, 8).map((u) => v.url(u, 'Gallery image URL'))),
    amenities: JSON.stringify(v.list(b.amenities, 'Amenities', AMENITIES)),
    active: b.active === false || b.active === 0 ? 0 : 1,
  };
}

exports.create = (req, res) => {
  const h = parseHotel(req.body);
  const info = db.prepare(`INSERT INTO hotels (name, city, state, address, description, stars, image, gallery, amenities, active)
    VALUES (@name, @city, @state, @address, @description, @stars, @image, @gallery, @amenities, @active)`).run(h);
  broadcast('availability', { hotelId: Number(info.lastInsertRowid), reason: 'hotel' });
  res.status(201).json({ hotel: shapeHotel(db.prepare(`${HOTEL_SELECT} WHERE h.id = ?`).get(info.lastInsertRowid)) });
};

exports.update = (req, res) => {
  if (!db.prepare('SELECT 1 FROM hotels WHERE id = ?').get(req.params.id)) throw new ApiError(404, 'Hotel not found');
  const h = parseHotel(req.body);
  db.prepare(`UPDATE hotels SET name=@name, city=@city, state=@state, address=@address, description=@description,
    stars=@stars, image=@image, gallery=@gallery, amenities=@amenities, active=@active WHERE id=@id`).run({ ...h, id: req.params.id });
  broadcast('availability', { hotelId: Number(req.params.id), reason: 'hotel' });
  res.json({ hotel: shapeHotel(db.prepare(`${HOTEL_SELECT} WHERE h.id = ?`).get(req.params.id)) });
};

exports.remove = (req, res) => {
  const id = Number(req.params.id);
  if (!db.prepare('SELECT 1 FROM hotels WHERE id = ?').get(id)) throw new ApiError(404, 'Hotel not found');
  const upcoming = db.prepare(`SELECT COUNT(*) AS c FROM bookings WHERE hotel_id = ? AND status = 'CONFIRMED' AND check_out > ?`).get(id, today()).c;
  if (upcoming) throw new ApiError(409, `This hotel has ${upcoming} upcoming booking(s). Cancel them first.`);
  const history = db.prepare('SELECT COUNT(*) AS c FROM bookings WHERE hotel_id = ?').get(id).c;
  if (history) {
    // keep booking history intact: hide the hotel instead of deleting it
    db.prepare('UPDATE hotels SET active = 0 WHERE id = ?').run(id);
    broadcast('availability', { hotelId: id, reason: 'hotel' });
    return res.json({ message: 'Hotel has booking history, so it was deactivated instead of deleted.', deactivated: true });
  }
  db.prepare('DELETE FROM hotels WHERE id = ?').run(id);
  broadcast('availability', { hotelId: id, reason: 'hotel' });
  res.json({ message: 'Hotel deleted', deleted: true });
};
