const db = require('../db/database');
const ApiError = require('../utils/ApiError');
const v = require('../middleware/validate');
const { validateStay, today } = require('../utils/dates');
const { roomAvailability, peakFutureUsage } = require('../utils/availability');
const { calculatePrice } = require('../utils/pricing');
const { broadcast } = require('../utils/events');
const { shapeRoom, shapeHotel, AMENITIES } = require('./hotelsController');

const ROOM_AMENITIES = AMENITIES;

// GET /api/rooms/:id  (room + its hotel; used by the booking page)
exports.getOne = (req, res) => {
  const r = db.prepare('SELECT * FROM rooms WHERE id = ?').get(req.params.id);
  if (!r) throw new ApiError(404, 'Room not found');
  const h = db.prepare('SELECT * FROM hotels WHERE id = ?').get(r.hotel_id);
  res.json({ room: shapeRoom(r), hotel: shapeHotel(h) });
};

// GET /api/rooms/:id/availability?checkIn&checkOut&rooms
exports.availability = (req, res) => {
  const r = db.prepare('SELECT * FROM rooms WHERE id = ? AND active = 1').get(req.params.id);
  if (!r) throw new ApiError(404, 'Room not found');
  const nights = validateStay(req.query.checkIn, req.query.checkOut);
  const rooms = v.int(req.query.rooms, 'Rooms', 1, 9, 1);
  const available = roomAvailability(r.id, req.query.checkIn, req.query.checkOut);
  res.json({
    roomId: r.id, available, totalUnits: r.total_units, nights, canBook: available >= rooms,
    quote: calculatePrice({ pricePerNight: r.price_per_night, nights, rooms }),
  });
};

function parseRoom(b) {
  return {
    name: v.str(b.name, 'Room name', { min: 2, max: 80 }),
    type: v.str(b.type, 'Room type', { optional: true, max: 30 }) || 'standard',
    price_per_night: v.num(b.pricePerNight, 'Price per night', 1, 1000000),
    capacity: v.int(b.capacity, 'Capacity', 1, 10),
    total_units: v.int(b.totalUnits, 'Number of rooms of this type', 1, 500),
    beds: v.str(b.beds, 'Beds', { optional: true, max: 60 }),
    size_sqm: v.int(b.sizeSqm, 'Room size', 5, 500, 20),
    image: v.url(b.image, 'Image URL'),
    amenities: JSON.stringify(v.list(b.amenities, 'Amenities', ROOM_AMENITIES)),
  };
}

exports.create = (req, res) => {
  if (!db.prepare('SELECT 1 FROM hotels WHERE id = ?').get(req.params.hotelId)) throw new ApiError(404, 'Hotel not found');
  const r = parseRoom(req.body);
  const info = db.prepare(`INSERT INTO rooms (hotel_id, name, type, price_per_night, capacity, total_units, beds, size_sqm, image, amenities)
    VALUES (@hotel_id, @name, @type, @price_per_night, @capacity, @total_units, @beds, @size_sqm, @image, @amenities)`)
    .run({ ...r, hotel_id: req.params.hotelId });
  broadcast('availability', { hotelId: Number(req.params.hotelId), reason: 'room' });
  res.status(201).json({ room: shapeRoom(db.prepare('SELECT * FROM rooms WHERE id = ?').get(info.lastInsertRowid)) });
};

exports.update = (req, res) => {
  const cur = db.prepare('SELECT * FROM rooms WHERE id = ?').get(req.params.id);
  if (!cur) throw new ApiError(404, 'Room not found');
  const r = parseRoom(req.body);
  const used = peakFutureUsage(cur.id, today());
  if (r.total_units < used)
    throw new ApiError(409, `Cannot reduce to ${r.total_units}: up to ${used} rooms of this type are already booked on a future night.`);
  db.prepare(`UPDATE rooms SET name=@name, type=@type, price_per_night=@price_per_night, capacity=@capacity,
    total_units=@total_units, beds=@beds, size_sqm=@size_sqm, image=@image, amenities=@amenities WHERE id=@id`)
    .run({ ...r, id: cur.id });
  broadcast('availability', { hotelId: cur.hotel_id, roomId: cur.id, reason: 'room' });
  res.json({ room: shapeRoom(db.prepare('SELECT * FROM rooms WHERE id = ?').get(cur.id)) });
};

exports.remove = (req, res) => {
  const cur = db.prepare('SELECT * FROM rooms WHERE id = ?').get(req.params.id);
  if (!cur) throw new ApiError(404, 'Room not found');
  const upcoming = db.prepare(`SELECT COUNT(*) AS c FROM bookings WHERE room_id = ? AND status = 'CONFIRMED' AND check_out > ?`).get(cur.id, today()).c;
  if (upcoming) throw new ApiError(409, `This room has ${upcoming} upcoming booking(s). Cancel them first.`);
  const history = db.prepare('SELECT COUNT(*) AS c FROM bookings WHERE room_id = ?').get(cur.id).c;
  if (history) db.prepare('UPDATE rooms SET active = 0 WHERE id = ?').run(cur.id);
  else db.prepare('DELETE FROM rooms WHERE id = ?').run(cur.id);
  broadcast('availability', { hotelId: cur.hotel_id, roomId: cur.id, reason: 'room' });
  res.json({ message: history ? 'Room has booking history, so it was deactivated instead of deleted.' : 'Room deleted', deactivated: !!history });
};
