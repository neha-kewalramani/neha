// Tiny stateless auth: a signed token (HMAC) that carries the user id. No external libraries needed.
const crypto = require('crypto');
const db = require('../db/database');
const ApiError = require('../utils/ApiError');

const SECRET = process.env.TOKEN_SECRET || 'stayease-dev-secret-change-me';
const sig = (body) => crypto.createHmac('sha256', SECRET).update(body).digest('base64url');

function signToken(user) {
  const body = Buffer.from(JSON.stringify({ id: user.id, exp: Date.now() + 7 * 864e5 })).toString('base64url');
  return `${body}.${sig(body)}`;
}
function verifyToken(token) {
  const [body, given] = String(token || '').split('.');
  if (!body || !given) return null;
  const a = Buffer.from(given), b = Buffer.from(sig(body));
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const p = JSON.parse(Buffer.from(body, 'base64url').toString());
    return p.exp > Date.now() ? p : null;
  } catch { return null; }
}

function hashPassword(pw) {
  const salt = crypto.randomBytes(16).toString('hex');
  return `${salt}:${crypto.scryptSync(pw, salt, 64).toString('hex')}`;
}
function checkPassword(pw, stored) {
  const [salt, hash] = stored.split(':');
  const test = crypto.scryptSync(pw, salt, 64);
  return crypto.timingSafeEqual(test, Buffer.from(hash, 'hex'));
}

// Runs on every request: if a valid token is present, req.user is filled in.
function attachUser(req, res, next) {
  const m = /^Bearer (.+)$/.exec(req.headers.authorization || '');
  const payload = m && verifyToken(m[1]);
  if (payload) {
    const u = db.prepare('SELECT id, name, email, role FROM users WHERE id = ?').get(payload.id);
    if (u) req.user = u;
  }
  next();
}
const requireAuth = (req, res, next) =>
  req.user ? next() : next(new ApiError(401, 'Please log in to continue'));
const requireAdmin = (req, res, next) => {
  if (!req.user) return next(new ApiError(401, 'Please log in to continue'));
  if (req.user.role !== 'admin') return next(new ApiError(403, 'Admin access required'));
  next();
};

module.exports = { signToken, hashPassword, checkPassword, attachUser, requireAuth, requireAdmin };
