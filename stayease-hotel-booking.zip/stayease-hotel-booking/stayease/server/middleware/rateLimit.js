// Very small in-memory rate limiter (protects the login endpoint from password guessing).
const ApiError = require('../utils/ApiError');
module.exports = function rateLimit({ windowMs = 60000, max = 30 } = {}) {
  const hits = new Map();
  return (req, res, next) => {
    const now = Date.now();
    const rec = hits.get(req.ip) || { count: 0, reset: now + windowMs };
    if (now > rec.reset) { rec.count = 0; rec.reset = now + windowMs; }
    rec.count++;
    hits.set(req.ip, rec);
    if (rec.count > max) return next(new ApiError(429, 'Too many attempts. Please wait a minute and try again.'));
    next();
  };
};
