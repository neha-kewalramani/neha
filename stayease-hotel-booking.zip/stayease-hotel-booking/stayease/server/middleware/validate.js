// Small, readable validators. Each one returns a cleaned value or throws a 400 ApiError.
const ApiError = require('../utils/ApiError');
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const PHONE = /^(\+91)?[6-9]\d{9}$/;

function str(v, label, { min = 1, max = 255, optional = false } = {}) {
  const s = String(v ?? '').trim();
  if (!s) {
    if (optional) return '';
    throw new ApiError(400, `${label} is required`);
  }
  if (s.length < min) throw new ApiError(400, `${label} must be at least ${min} characters`);
  if (s.length > max) throw new ApiError(400, `${label} must be at most ${max} characters`);
  return s;
}
function int(v, label, min, max, def) {
  if ((v === undefined || v === null || v === '') && def !== undefined) return def;
  const n = Number(v);
  if (!Number.isInteger(n) || n < min || n > max) throw new ApiError(400, `${label} must be a whole number between ${min} and ${max}`);
  return n;
}
function num(v, label, min, max) {
  const n = Number(v);
  if (v === '' || v === null || v === undefined || !Number.isFinite(n) || n < min || n > max)
    throw new ApiError(400, `${label} must be a number between ${min} and ${max}`);
  return n;
}
function email(v, label = 'Email') {
  const s = str(v, label, { max: 120 }).toLowerCase();
  if (!EMAIL.test(s)) throw new ApiError(400, `${label} is not a valid email address`);
  return s;
}
function phone(v, label = 'Phone number') {
  const s = str(v, label, { max: 20 });
  if (!PHONE.test(s.replace(/[\s-]/g, ''))) throw new ApiError(400, `${label} must be a valid 10-digit Indian mobile number`);
  return s.replace(/[\s-]/g, '');
}
function url(v, label) {
  const s = str(v, label, { optional: true, max: 600 });
  if (s && !/^(https?:\/\/|\/)/i.test(s)) throw new ApiError(400, `${label} must start with http://, https:// or /`);
  return s;
}
function list(v, label, allowed, max = 20) {
  if (v === undefined || v === null) return [];
  if (!Array.isArray(v)) throw new ApiError(400, `${label} must be a list`);
  const out = [...new Set(v.map((x) => String(x).trim()).filter(Boolean))];
  if (out.length > max) throw new ApiError(400, `${label} can have at most ${max} items`);
  if (allowed) {
    const bad = out.find((x) => !allowed.includes(x));
    if (bad) throw new ApiError(400, `Unknown ${label.toLowerCase()} value: ${bad}`);
  }
  return out;
}
module.exports = { str, int, num, email, phone, url, list };
