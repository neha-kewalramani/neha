// All booking rules live here: create (with double-booking protection), cancel, reinstate.
const crypto = require('crypto');
const db = require('../db/database');
const ApiError = require('./ApiError');
const v = require('../middleware/validate');
const { validateStay, today, diffDays } = require('./dates');
const { roomAvailability } = require('./availability');
const { calculatePrice } = require('./pricing');
const { broadcast } = require('./events');

const BOOKING_SELECT = `
  SELECT b.*, h.name AS hotel_name, h.city AS hotel_city, h.address AS hotel_address, h.image AS hotel_image,
         r.name AS room_name, u.name AS user_name, u.email AS user_email,
         EXISTS (SELECT 1 FROM reviews v WHERE v.booking_id = b.id) AS reviewed
  FROM bookings b
  JOIN hotels h ON h.id = b.hotel_id
  JOIN rooms  r ON r.id = b.room_id
  JOIN users  u ON u.id = b.user_id`;

// Refund policy: 100% if cancelled 2+ days before check-in, 50% one day before, otherwise nothing.
const refundPct = (checkIn) => {
  const d = diffDays(today(), checkIn);
  return d >= 2 ? 100 : d === 1 ? 50 : 0;
};

function formatBooking(b, withGuests = true) {
  const t = today();
  const phase = b.status === 'CANCELLED' ? 'cancelled' : b.check_out <= t ? 'past' : b.check_in <= t ? 'ongoing' : 'upcoming';
  const canCancel = b.status === 'CONFIRMED' && b.check_in >= t;
  return {
    id: b.id, ref: b.booking_ref, status: b.status, phase, canCancel,
    refundPreview: canCancel ? Math.round(b.total_amount * refundPct(b.check_in)) / 100 : 0,
    refundPercent: canCancel ? refundPct(b.check_in) : 0,
    reviewed: !!b.reviewed,
    hotel: { id: b.hotel_id, name: b.hotel_name, city: b.hotel_city, address: b.hotel_address, image: b.hotel_image },
    room: { id: b.room_id, name: b.room_name },
    user: { id: b.user_id, name: b.user_name, email: b.user_email },
    checkIn: b.check_in, checkOut: b.check_out, nights: b.nights, rooms: b.rooms_count,
    adults: b.adults, children: b.children,
    pricing: {
      base: b.base_amount, discount: b.discount_amount, coupon: b.coupon_code,
      tax: b.tax_amount, total: b.total_amount, refund: b.refund_amount,
    },
    specialRequests: b.special_requests, createdAt: b.created_at, cancelledAt: b.cancelled_at,
    guests: withGuests
      ? db.prepare('SELECT name, email, phone, is_primary AS isPrimary FROM guests WHERE booking_id = ? ORDER BY id').all(b.id)
      : undefined,
  };
}

function getBooking(idOrRef) {
  const row = typeof idOrRef === 'number'
    ? db.prepare(`${BOOKING_SELECT} WHERE b.id = ?`).get(idOrRef)
    : db.prepare(`${BOOKING_SELECT} WHERE b.booking_ref = ?`).get(idOrRef);
  return row ? formatBooking(row) : null;
}

function makeRef() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  for (;;) {
    let s = '';
    for (let i = 0; i < 6; i++) s += chars[crypto.randomInt(chars.length)];
    const ref = `SE-${today().slice(2, 4)}${today().slice(5, 7)}-${s}`;
    if (!db.prepare('SELECT 1 FROM bookings WHERE booking_ref = ?').get(ref)) return ref;
  }
}

function parseGuests(list) {
  if (!Array.isArray(list) || !list.length) throw new ApiError(400, 'Guest details are required');
  if (list.length > 20) throw new ApiError(400, 'Too many guests listed');
  return list.map((g, i) => {
    g = g || {};
    if (i === 0)
      return { name: v.str(g.name, 'Guest name', { min: 2, max: 80 }), email: v.email(g.email), phone: v.phone(g.phone) };
    return {
      name: v.str(g.name, `Guest ${i + 1} name`, { min: 2, max: 80 }),
      email: g.email ? v.email(g.email) : '',
      phone: g.phone ? v.phone(g.phone) : '',
    };
  });
}

// The heart of the system. The whole check-then-insert runs inside ONE "BEGIN IMMEDIATE" transaction,
// so SQLite lets only one booking at a time check availability and write. That is what makes
// double-booking impossible, even if two people click "Confirm" in the same millisecond.
function createBooking(userId, input, opts = {}) {
  const roomId = v.int(input.roomId, 'Room', 1, 1e9);
  const rooms = v.int(input.rooms, 'Number of rooms', 1, 9, 1);
  const adults = v.int(input.adults, 'Adults', 1, 40, 1);
  const children = v.int(input.children, 'Children', 0, 20, 0);
  const special = v.str(input.specialRequests, 'Special requests', { optional: true, max: 500 });
  const guests = parseGuests(input.guests);

  const run = db.transaction(() => {
    const room = db.prepare(`SELECT r.*, h.active AS hotel_active FROM rooms r
      JOIN hotels h ON h.id = r.hotel_id WHERE r.id = ?`).get(roomId);
    if (!room || !room.active || !room.hotel_active) throw new ApiError(404, 'This room is no longer available for booking');
    const nights = validateStay(input.checkIn, input.checkOut, { allowPast: opts.allowPast });
    if (adults < rooms) throw new ApiError(400, 'Each room needs at least one adult');
    if (adults + children > room.capacity * rooms)
      throw new ApiError(400, `${room.name} fits ${room.capacity} guests per room. Please add more rooms.`);

    const available = roomAvailability(room.id, input.checkIn, input.checkOut);
    if (available < rooms)
      throw new ApiError(409, available === 0
        ? 'Sorry, this room just sold out for your dates. Please pick different dates or another room.'
        : `Only ${available} room(s) left for your dates. Please reduce the number of rooms.`);

    const p = calculatePrice({ pricePerNight: room.price_per_night, nights, rooms, coupon: input.coupon });
    const info = db.prepare(`INSERT INTO bookings
      (booking_ref, user_id, hotel_id, room_id, check_in, check_out, nights, rooms_count, adults, children,
       base_amount, discount_amount, coupon_code, tax_amount, total_amount, special_requests, created_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, COALESCE(?, datetime('now')))`)
      .run(makeRef(), userId, room.hotel_id, room.id, input.checkIn, input.checkOut, nights, rooms, adults, children,
        p.base, p.discount, p.coupon, p.tax, p.total, special, opts.createdAt || null);
    const ins = db.prepare('INSERT INTO guests (booking_id, name, email, phone, is_primary) VALUES (?,?,?,?,?)');
    guests.forEach((g, i) => ins.run(info.lastInsertRowid, g.name, g.email, g.phone, i === 0 ? 1 : 0));
    return { id: Number(info.lastInsertRowid), hotelId: room.hotel_id, roomId: room.id };
  });

  const r = run.immediate();
  if (!opts.silent) broadcast('availability', { hotelId: r.hotelId, roomId: r.roomId, reason: 'booked' });
  return getBooking(r.id);
}

function cancelBooking(ref, actor, opts = {}) {
  const b = db.prepare('SELECT * FROM bookings WHERE booking_ref = ?').get(ref);
  if (!b || (actor.role !== 'admin' && b.user_id !== actor.id)) throw new ApiError(404, 'Booking not found');
  if (b.status === 'CANCELLED') throw new ApiError(409, 'This booking is already cancelled');
  if (!opts.force && b.check_in < today())
    throw new ApiError(400, 'This stay has already started, so it can no longer be cancelled online. Please contact the hotel.');
  const pct = opts.refundPct ?? (actor.role === 'admin' ? 100 : refundPct(b.check_in));
  const refund = Math.round(b.total_amount * pct) / 100;
  db.prepare(`UPDATE bookings SET status = 'CANCELLED', refund_amount = ?, cancelled_at = datetime('now') WHERE id = ?`)
    .run(refund, b.id);
  broadcast('availability', { hotelId: b.hotel_id, roomId: b.room_id, reason: 'cancelled' });
  return getBooking(b.id);
}

// Admin: bring a cancelled booking back (only if the rooms are still free).
function reinstateBooking(id) {
  const run = db.transaction(() => {
    const b = db.prepare('SELECT * FROM bookings WHERE id = ?').get(id);
    if (!b) throw new ApiError(404, 'Booking not found');
    if (b.status === 'CONFIRMED') throw new ApiError(409, 'This booking is already confirmed');
    if (b.check_in < today()) throw new ApiError(400, 'Past bookings cannot be reinstated');
    if (roomAvailability(b.room_id, b.check_in, b.check_out) < b.rooms_count)
      throw new ApiError(409, 'Those rooms have since been booked by someone else, so this booking cannot be reinstated');
    db.prepare(`UPDATE bookings SET status = 'CONFIRMED', refund_amount = 0, cancelled_at = NULL WHERE id = ?`).run(id);
    return b;
  });
  const b = run.immediate();
  broadcast('availability', { hotelId: b.hotel_id, roomId: b.room_id, reason: 'booked' });
  return getBooking(id);
}

module.exports = { BOOKING_SELECT, formatBooking, getBooking, createBooking, cancelBooking, reinstateBooking, refundPct };
