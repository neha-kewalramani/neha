// All dates are plain 'YYYY-MM-DD' strings. We do date maths in UTC so time zones never shift a day.
const ApiError = require('./ApiError');
const RE = /^\d{4}-\d{2}-\d{2}$/;

const isValidDate = (s) => {
  if (typeof s !== 'string' || !RE.test(s)) return false;
  const d = new Date(s + 'T00:00:00Z');
  return !isNaN(d) && d.toISOString().slice(0, 10) === s;
};
const addDays = (s, n) => {
  const d = new Date(s + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
};
const diffDays = (a, b) => Math.round((new Date(b + 'T00:00:00Z') - new Date(a + 'T00:00:00Z')) / 86400000);
const today = () => {
  const d = new Date();
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
};
const nightsOf = (ci, co) => {
  const out = [];
  for (let d = ci; d < co; d = addDays(d, 1)) out.push(d);
  return out;
};

function validateStay(checkIn, checkOut, { allowPast = false } = {}) {
  if (!isValidDate(checkIn) || !isValidDate(checkOut))
    throw new ApiError(400, 'Please provide valid check-in and check-out dates (YYYY-MM-DD)');
  const nights = diffDays(checkIn, checkOut);
  if (nights < 1) throw new ApiError(400, 'Check-out must be after check-in');
  if (nights > 30) throw new ApiError(400, 'The maximum stay is 30 nights');
  if (!allowPast && checkIn < today()) throw new ApiError(400, 'Check-in date cannot be in the past');
  return nights;
}

module.exports = { isValidDate, addDays, diffDays, today, nightsOf, validateStay };
