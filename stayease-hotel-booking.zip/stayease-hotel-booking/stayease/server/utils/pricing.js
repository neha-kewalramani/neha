// Single source of truth for price maths (used by the quote API, booking API and seed data).
const ApiError = require('./ApiError');
const r2 = (n) => Math.round(n * 100) / 100;

const COUPONS = {
  WELCOME10: { type: 'percent', value: 10, max: 2000, minNights: 1, label: '10% off, up to ₹2,000' },
  STAY15: { type: 'percent', value: 15, max: 5000, minNights: 3, label: '15% off on stays of 3+ nights, up to ₹5,000' },
  FLAT500: { type: 'flat', value: 500, minNights: 1, label: 'Flat ₹500 off' },
};

// Indian GST slabs for hotel rooms, based on the room tariff per night.
const gstRate = (perRoomNight) => (perRoomNight <= 1000 ? 0 : perRoomNight <= 7500 ? 12 : 18);

function calculatePrice({ pricePerNight, nights, rooms, coupon }) {
  const base = r2(pricePerNight * nights * rooms);
  const stayPct = nights >= 7 ? 15 : nights >= 5 ? 10 : nights >= 3 ? 5 : 0; // long-stay discount
  const stayDiscount = r2((base * stayPct) / 100);

  let couponDiscount = 0;
  let code = null;
  if (coupon && String(coupon).trim()) {
    code = String(coupon).trim().toUpperCase();
    const c = COUPONS[code];
    if (!c) throw new ApiError(400, `Coupon "${code}" is not valid`);
    if (nights < c.minNights) throw new ApiError(400, `${code} needs a stay of at least ${c.minNights} nights`);
    const after = base - stayDiscount;
    couponDiscount = r2(c.type === 'percent' ? Math.min((after * c.value) / 100, c.max) : Math.min(c.value, after));
  }

  const discount = r2(stayDiscount + couponDiscount);
  const taxable = r2(base - discount);
  const taxRate = gstRate(taxable / (nights * rooms));
  const tax = r2((taxable * taxRate) / 100);
  return {
    pricePerNight, nights, rooms, base,
    stayDiscountPct: stayPct, stayDiscount,
    coupon: code, couponDiscount,
    discount, taxable, taxRate, tax,
    total: r2(taxable + tax),
  };
}

module.exports = { calculatePrice, COUPONS, gstRate };
