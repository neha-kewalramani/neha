// Run with:  npm test      (uses a temporary database, your real data is untouched)
const test = require('node:test');
const assert = require('node:assert/strict');
const os = require('os');
const path = require('path');
const fs = require('fs');

const DB = path.join(os.tmpdir(), `stayease-test-${process.pid}.sqlite`);
process.env.DB_PATH = DB;
const app = require('../server/app');
const { addDays, today } = require('../server/utils/dates');

let server, base, admin, demo, fresh;
const call = async (method, url, body, token) => {
  const res = await fetch(base + url, {
    method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: res.status, body: await res.json().catch(() => ({})) };
};
const login = async (email, password) => (await call('POST', '/auth/login', { email, password })).body.token;
const guest = (n = 'Test Guest') => [{ name: n, email: 'guest@example.com', phone: '9876543210' }];

test.before(async () => {
  server = app.listen(0);
  base = `http://127.0.0.1:${server.address().port}/api`;
  admin = await login('admin@stayease.com', 'admin123');
  demo = await login('demo@stayease.com', 'demo123');
});
test.after(() => {
  server.closeAllConnections?.();
  server.close();
  for (const s of ['', '-wal', '-shm']) fs.rmSync(DB + s, { force: true });
});

// A brand-new hotel with ONE room of ONE unit, priced ₹5,000: perfect for exact maths and overlap tests.
let hotelId, roomId;
test('TC01 admin can create a hotel and a room', async () => {
  const h = await call('POST', '/hotels', { name: 'Test Inn', city: 'Testville', stars: 3, amenities: ['wifi'] }, admin);
  assert.equal(h.status, 201);
  hotelId = h.body.hotel.id;
  const r = await call('POST', `/hotels/${hotelId}/rooms`, { name: 'Solo Room', pricePerNight: 5000, capacity: 2, totalUnits: 1 }, admin);
  assert.equal(r.status, 201);
  roomId = r.body.room.id;
});

test('TC02 non-admins cannot write hotels (401 / 403)', async () => {
  assert.equal((await call('POST', '/hotels', { name: 'X', city: 'Y', stars: 3 })).status, 401);
  assert.equal((await call('POST', '/hotels', { name: 'X', city: 'Y', stars: 3 }, demo)).status, 403);
});

test('TC03 search returns seeded hotels and supports filters + sorting', async () => {
  const all = await call('GET', '/hotels?limit=50');
  assert.ok(all.body.total >= 16);
  const goa = await call('GET', '/hotels?q=Goa');
  assert.ok(goa.body.hotels.length >= 2 && goa.body.hotels.every((h) => h.city === 'Goa'));
  const asc = (await call('GET', '/hotels?sort=price_asc&limit=50')).body.hotels.map((h) => h.fromPrice);
  assert.deepEqual(asc, [...asc].sort((a, b) => a - b));
  const five = await call('GET', '/hotels?stars=5&amenities=pool,spa');
  assert.ok(five.body.hotels.every((h) => h.stars === 5 && h.amenities.includes('pool') && h.amenities.includes('spa')));
});

test('TC04 price calculation: nights, discount and GST are exact', async () => {
  const ci = addDays(today(), 40);
  const q = await call('POST', '/bookings/quote', { roomId, checkIn: ci, checkOut: addDays(ci, 3), rooms: 1 });
  const p = q.body.price;
  // base 15000, 5% long-stay discount = 750, taxable 14250, GST 12% = 1710, total 15960
  assert.deepEqual([p.nights, p.base, p.discount, p.taxable, p.taxRate, p.tax, p.total], [3, 15000, 750, 14250, 12, 1710, 15960]);
  const c = await call('POST', '/bookings/quote', { roomId, checkIn: ci, checkOut: addDays(ci, 3), rooms: 1, coupon: 'FLAT500' });
  assert.equal(c.body.price.discount, 1250);
  const bad = await call('POST', '/bookings/quote', { roomId, checkIn: ci, checkOut: addDays(ci, 1), rooms: 1, coupon: 'NOPE' });
  assert.equal(bad.status, 400);
});

test('TC05 validation: bad dates, past dates, bad guests', async () => {
  const ci = addDays(today(), 50);
  const b = (o) => call('POST', '/bookings', { roomId, checkIn: ci, checkOut: addDays(ci, 2), rooms: 1, adults: 2, guests: guest(), ...o }, demo);
  assert.equal((await call('POST', '/bookings', { roomId }, demo)).status, 400);
  assert.equal((await b({ checkOut: ci })).status, 400);
  assert.equal((await b({ checkIn: addDays(today(), -2), checkOut: addDays(today(), 1) })).status, 400);
  assert.equal((await b({ adults: 5 })).status, 400);
  assert.equal((await b({ guests: [{ name: 'A', email: 'bad', phone: '1' }] })).status, 400);
  assert.equal((await call('POST', '/bookings', { roomId, checkIn: ci, checkOut: addDays(ci, 2), adults: 1, guests: guest() })).status, 401);
});

let ref;
const ci0 = addDays(today(), 60);
test('TC06 booking succeeds and returns a unique Booking ID', async () => {
  const r = await call('POST', '/bookings', { roomId, checkIn: ci0, checkOut: addDays(ci0, 3), rooms: 1, adults: 2, guests: guest(), specialRequests: 'Late check-in' }, demo);
  assert.equal(r.status, 201);
  assert.match(r.body.booking.ref, /^SE-\d{4}-[A-Z0-9]{6}$/);
  assert.equal(r.body.booking.pricing.total, 15960);
  assert.equal(r.body.booking.guests.length, 1);
  ref = r.body.booking.ref;
});

test('TC07 overlapping bookings are rejected (double-booking prevention)', async () => {
  const tryBook = (a, n) => call('POST', '/bookings', { roomId, checkIn: addDays(ci0, a), checkOut: addDays(ci0, a + n), rooms: 1, adults: 1, guests: guest() }, demo);
  assert.equal((await tryBook(0, 3)).status, 409);   // exact same dates
  assert.equal((await tryBook(-1, 2)).status, 409);  // overlaps the first night
  assert.equal((await tryBook(2, 3)).status, 409);   // overlaps the last night
  assert.equal((await tryBook(1, 1)).status, 409);   // inside the stay
  assert.equal((await tryBook(-2, 8)).status, 409);  // surrounds the stay
  assert.equal((await tryBook(3, 2)).status, 201);   // starts on the check-out day: allowed
  assert.equal((await tryBook(-2, 2)).status, 201);  // ends on the check-in day: allowed
});

test('TC08 availability reflects bookings in real time', async () => {
  const a = await call('GET', `/rooms/${roomId}/availability?checkIn=${ci0}&checkOut=${addDays(ci0, 3)}`);
  assert.equal(a.body.available, 0);
  assert.equal(a.body.canBook, false);
  const free = await call('GET', `/rooms/${roomId}/availability?checkIn=${addDays(ci0, 10)}&checkOut=${addDays(ci0, 12)}`);
  assert.equal(free.body.available, 1);
  const detail = await call('GET', `/hotels/${hotelId}?checkIn=${ci0}&checkOut=${addDays(ci0, 3)}`);
  assert.equal(detail.body.rooms[0].available, 0);
});

test('TC09 concurrent requests: exactly one wins the last room', async () => {
  const ci = addDays(today(), 90);
  const results = await Promise.all(Array.from({ length: 6 }, () =>
    call('POST', '/bookings', { roomId, checkIn: ci, checkOut: addDays(ci, 2), rooms: 1, adults: 1, guests: guest() }, demo)));
  assert.equal(results.filter((r) => r.status === 201).length, 1);
  assert.equal(results.filter((r) => r.status === 409).length, 5);
});

test('TC10 my bookings + access control on a booking', async () => {
  const mine = await call('GET', '/bookings/mine', null, demo);
  assert.ok(mine.body.bookings.some((b) => b.ref === ref));
  const reg = await call('POST', '/auth/register', { name: 'Other Person', email: `other${Date.now()}@example.com`, password: 'secret12' });
  assert.equal(reg.status, 201);
  fresh = reg.body.token;
  assert.equal((await call('GET', `/bookings/${ref}`, null, fresh)).status, 404);
  assert.equal((await call('DELETE', `/bookings/${ref}`, null, fresh)).status, 404);
  assert.equal((await call('GET', `/bookings/${ref}`, null, demo)).status, 200);
});

test('TC11 cancellation: refund, freed availability, no double cancel', async () => {
  const c = await call('DELETE', `/bookings/${ref}`, null, demo);
  assert.equal(c.status, 200);
  assert.equal(c.body.booking.status, 'CANCELLED');
  assert.equal(c.body.booking.pricing.refund, 15960); // 60 days ahead = 100% refund
  const a = await call('GET', `/rooms/${roomId}/availability?checkIn=${ci0}&checkOut=${addDays(ci0, 3)}`);
  assert.equal(a.body.available, 1);
  assert.equal((await call('DELETE', `/bookings/${ref}`, null, demo)).status, 409);
});

test('TC12 auth: duplicate email, weak password, wrong password', async () => {
  assert.equal((await call('POST', '/auth/register', { name: 'Dup', email: 'demo@stayease.com', password: 'abcdef' })).status, 409);
  assert.equal((await call('POST', '/auth/register', { name: 'Weak', email: 'weak@example.com', password: '123' })).status, 400);
  assert.equal((await call('POST', '/auth/register', { name: 'Bad', email: 'not-an-email', password: 'abcdef' })).status, 400);
  assert.equal((await call('POST', '/auth/login', { email: 'demo@stayease.com', password: 'wrong' })).status, 401);
});

test('TC13 reviews: only after a completed stay, once per booking', async () => {
  assert.equal((await call('POST', `/hotels/${hotelId}/reviews`, { bookingId: 1, rating: 5, comment: 'Nice place' }, fresh)).status, 403);
  const mine = (await call('GET', '/bookings/mine', null, demo)).body.bookings.find((b) => b.phase === 'past' && !b.reviewed);
  assert.ok(mine, 'demo user has an unreviewed past stay');
  const body = { bookingId: mine.id, rating: 4, comment: 'Comfortable and clean.' };
  assert.equal((await call('POST', `/hotels/${mine.hotel.id}/reviews`, body, demo)).status, 201);
  assert.equal((await call('POST', `/hotels/${mine.hotel.id}/reviews`, body, demo)).status, 409);
});

test('TC14 admin dashboard, booking management and guests', async () => {
  assert.equal((await call('GET', '/admin/stats', null, demo)).status, 403);
  const s = await call('GET', '/admin/stats', null, admin);
  assert.equal(s.status, 200);
  assert.ok(s.body.revenue > 0 && s.body.occupancy >= 0 && s.body.monthlyRevenue.length > 0);
  const list = await call('GET', '/admin/bookings?status=CANCELLED&q=' + ref, null, admin);
  assert.equal(list.body.bookings.length, 1);
  const id = list.body.bookings[0].id;
  // reinstate works while the room is still free, and fails once someone else takes it
  assert.equal((await call('PUT', `/admin/bookings/${id}`, { status: 'CONFIRMED' }, admin)).status, 200);
  assert.equal((await call('PUT', `/admin/bookings/${id}`, { status: 'CANCELLED' }, admin)).status, 200);
  await call('POST', '/bookings', { roomId, checkIn: ci0, checkOut: addDays(ci0, 3), rooms: 1, adults: 1, guests: guest() }, demo);
  assert.equal((await call('PUT', `/admin/bookings/${id}`, { status: 'CONFIRMED' }, admin)).status, 409);
  assert.ok((await call('GET', '/admin/guests?q=Test', null, admin)).body.total > 0);
});

test('TC15 admin room/hotel update rules and delete behaviour', async () => {
  const upd = await call('PUT', `/rooms/${roomId}`, { name: 'Solo Room', pricePerNight: 5500, capacity: 2, totalUnits: 2 }, admin);
  assert.equal(upd.status, 200);
  assert.equal(upd.body.room.totalUnits, 2);
  assert.equal((await call('PUT', `/rooms/${roomId}`, { name: 'Solo Room', pricePerNight: -5, capacity: 2, totalUnits: 2 }, admin)).status, 400);
  assert.equal((await call('DELETE', `/hotels/${hotelId}`, null, admin)).status, 409); // has upcoming bookings
  const empty = (await call('POST', '/hotels', { name: 'Empty Inn', city: 'Nowhere', stars: 2 }, admin)).body.hotel.id;
  assert.equal((await call('DELETE', `/hotels/${empty}`, null, admin)).status, 200);
  assert.equal((await call('GET', `/hotels/${empty}`)).status, 404);
});

test('TC16 unknown routes and bad JSON return clean errors', async () => {
  assert.equal((await call('GET', '/nope')).status, 404);
  const res = await fetch(base + '/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{bad' });
  assert.equal(res.status, 400);
});
